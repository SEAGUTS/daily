#include <stdio.h>
#include <math.h>
// int power(int a , int b)
// {
//     int c = 1;
//     for (int i = b; i>=1; i--)
//     {
//         c = c * a;
//     }
//     return c;
// }
void main()
{
    int a = 3 , b = 6;
    float c = sqrt(b);
    printf("%f",c);
}