# hellospaced=" "
# for ch in "shreyansh":
#     hellospaced=hellospaced+ch+" "
# print(hellospaced)

# message = "shreyansh"
# print("sh" in message)
# n=len(message)
# print(n)

# message = "shreyansh"
# index=len(message)-1
# print(message[::3])
# print(message[:])
# print(message[0:5])
# print(message[-5:-1])



# print(message[6])
# print(message[index])
# print(message[-index-1])
# print(message[index - 5])

# print("institute".count('t'))

vowel = "aeiou"
vowelc=0
for ch in vowel:
    vowelc+="remote".count(ch)
print(vowelc)